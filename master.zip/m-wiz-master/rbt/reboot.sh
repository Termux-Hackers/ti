#reboot bash
echo " "
echo " "
cd $HOME
cd m-wiz
bash m-wiz.sh
echo " "
echo " "
