#colour section
red='\033[1;31m'
rset='\033[0m'
grn='\033[1;32m'
ylo='\033[1;33m'
#script coding starts
clear
echo " "
echo " "
echo '


            ___  ___  _    ___  ___  ___ 
           | . \| __>| |  | __>|_ _|| __>
           | | || _> | |_ | _>  | | | _> 
           |___/|___>|___||___> |_| |___>
                                         

                           
' | lolcat
echo " "
echo " "
echo -e "$grn              Hello buddy dont forget to give feedback$rset"
sleep 2.0
echo " "
echo " "
cd $HOME
rm -rf META-KIT
clear
echo " "
echo " "
echo -e "$grn          Thank you for $red using META-KIT tool,$ylo have a nice day$rset"
sleep 3.0
echo " "
echo " "
clear
cd $HOME
ls

