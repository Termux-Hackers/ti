clear
echo '                    

            __   __     _____   __       __       _____    
           /\_\ /_/\  /\_____\ /\_\     /\_\     ) ___ (   
          ( ( (_) ) )( (_____/( ( (    ( ( (    / /\_/\ \  
           \ \___/ /  \ \__\   \ \_\    \ \_\  / /_/ (_\ \ 
           / / _ \ \  / /__/_  / / /__  / / /__\ \ )_/ / / 
          ( (_( )_) )( (_____\( (_____(( (_____(\ \/_\/ /  
           \/_/ \_\/  \/_____/ \/_____/ \/_____/ )_____(   
                                                 
' | lolcat
echo " "
echo "                             About"|lolcat
echo " "
echo "       🙏 Hey, there I am Shoaib (Nitro), i made this tool
  to make the  installation of metasploit-framework in termux become 
       easy by this auto script you can install,repair,backup
    or, restore metasploit in termux easyli, so i hope guys you
                             liked it. 😘"
echo ""
echo "                  Our channel :- Mux Hackers"| lolcat
echo " "
